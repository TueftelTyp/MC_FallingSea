package de.fallingsea.client;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import de.fallingsea.network.ConfigSnapshotPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;

public final class FallingSeaClient implements ClientModInitializer {
    private static volatile boolean enabled;
    private static volatile long remaining;
    private static volatile int level;
    private static volatile long snapshotTime;

    @Override public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(ConfigSnapshotPayload.TYPE, (packet, context) ->
            context.client().execute(() -> {
                JsonObject json;
                try { json=JsonParser.parseString(packet.json()).getAsJsonObject(); }
                catch(RuntimeException e){return;}
                enabled=json.has("showCountdown") && json.get("showCountdown").getAsBoolean()
                    && json.has("enableDrying") && json.get("enableDrying").getAsBoolean()
                    && json.has("running") && json.get("running").getAsBoolean();
                remaining=json.has("countdownRemainingSeconds") ? Math.max(0,json.get("countdownRemainingSeconds").getAsLong()) : 0;
                level=json.has("currentWaterLevel") ? json.get("currentWaterLevel").getAsInt() : 63;
                snapshotTime=System.currentTimeMillis();
                if(context.client().gui.screen() instanceof FallingSeaConfigScreen screen)
                    screen.receiveSnapshot(json);
            })
        );
        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("fallingsea","countdown"),(graphics,delta)->{
            Minecraft mc=Minecraft.getInstance();
            if(mc.player==null || mc.gui.hud.isHidden() || !enabled || snapshotTime==0 || System.currentTimeMillis()-snapshotTime>4000)return;
            long seconds=Math.max(0,remaining - Math.max(0,(System.currentTimeMillis()-snapshotTime)/1000));
            String line="Falling Sea  -  " + seconds + "s  |  Y=" + level;
            int x=graphics.guiWidth()-mc.font.width(line)-12;
            graphics.text(mc.font,line,Math.max(4,x),8,0xFF65DFFF,true);
        });
    }
}
