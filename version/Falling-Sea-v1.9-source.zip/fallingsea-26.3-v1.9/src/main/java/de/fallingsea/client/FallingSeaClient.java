package de.fallingsea.client;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import de.fallingsea.network.ConfigSnapshotPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;

/**
 * A compact countdown card styled after the vanilla status-effect list.
 * It appears only during the configured warning window before the next lowering step.
 */
public final class FallingSeaClient implements ClientModInitializer {
    private static final int WIDTH = 120;
    private static final int HEIGHT = 32;
    private static final int ICON_X_OFFSET = 7;
    private static final int ICON_Y_OFFSET = 7;
    private static final long MAX_SNAPSHOT_AGE_MS = 4_000L;

    private static boolean countdownEnabled;
    private static int warningSeconds;
    private static long remainingSeconds;
    private static long snapshotTimeMs;

    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(ConfigSnapshotPayload.TYPE, (packet, context) ->
            context.client().execute(() -> {
                JsonObject json;
                try {
                    json = JsonParser.parseString(packet.json()).getAsJsonObject();
                    boolean show = json.get("showCountdown").getAsBoolean();
                    boolean enabled = json.get("enableDrying").getAsBoolean();
                    boolean running = json.get("running").getAsBoolean();
                    int level = json.get("currentWaterLevel").getAsInt();
                    int minimum = json.get("minWaterLevel").getAsInt();
                    int window = json.get("countdownLastSeconds").getAsInt();
                    long seconds = json.get("countdownRemainingSeconds").getAsLong();
                    warningSeconds = Math.max(0, Math.min(60, window));
                    remainingSeconds = Math.max(0, seconds);
                    countdownEnabled = show && enabled && running && level > minimum && warningSeconds > 0;
                    snapshotTimeMs = System.currentTimeMillis();
                } catch (RuntimeException exception) {
                    countdownEnabled = false;
                    snapshotTimeMs = 0;
                    return;
                }
                if (context.client().gui.screen() instanceof FallingSeaConfigScreen screen) {
                    screen.receiveSnapshot(json);
                }
            })
        );

        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("fallingsea", "countdown"), (graphics, delta) -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.gui.hud.isHidden() || !countdownEnabled) return;
            long age = System.currentTimeMillis() - snapshotTimeMs;
            if (snapshotTimeMs == 0 || age < 0 || age > MAX_SNAPSHOT_AGE_MS) return;

            long left = Math.max(0, remainingSeconds - age / 1_000L);
            if (left == 0 || left > warningSeconds) return;

            int x = Math.max(2, graphics.guiWidth() - WIDTH - 2);
            int y = 2;
            drawVanillaEffectCard(graphics, x, y);
            drawEffectIcon(graphics, x + ICON_X_OFFSET, y + ICON_Y_OFFSET);

            graphics.text(mc.font, "Austrocknung", x + 31, y + 6, 0xFFFFFFFF, false);
            long minutes = left / 60;
            long seconds = left % 60;
            String time = String.format(java.util.Locale.ROOT, "%d:%02d", minutes, seconds);
            graphics.text(mc.font, time, x + 31, y + 17, 0xFF7F7F7F, false);
        });
    }

    private static void drawVanillaEffectCard(net.minecraft.client.gui.GuiGraphicsExtractor graphics, int x, int y) {
        // Outer bevel similar to the vanilla effect list on the inventory screen.
        graphics.fill(x, y, x + WIDTH, y + HEIGHT, 0xFF0F0F0F);
        graphics.fill(x + 1, y + 1, x + WIDTH - 1, y + HEIGHT - 1, 0xFF1E1E1E);

        // Light top/left highlight.
        graphics.fill(x, y, x + WIDTH, y + 1, 0xFFFFFFFF);
        graphics.fill(x, y, x + 1, y + HEIGHT, 0xFFFFFFFF);
        graphics.fill(x + 1, y + 1, x + WIDTH - 1, y + 2, 0xFFB7B7B7);
        graphics.fill(x + 1, y + 1, x + 2, y + HEIGHT - 1, 0xFFB7B7B7);

        // Dark bottom/right shadow.
        graphics.fill(x, y + HEIGHT - 1, x + WIDTH, y + HEIGHT, 0xFF1A1A1A);
        graphics.fill(x + WIDTH - 1, y, x + WIDTH, y + HEIGHT, 0xFF1A1A1A);
        graphics.fill(x + 2, y + HEIGHT - 2, x + WIDTH - 1, y + HEIGHT - 1, 0xFF3A3A3A);
        graphics.fill(x + WIDTH - 2, y + 2, x + WIDTH - 1, y + HEIGHT - 2, 0xFF3A3A3A);
    }

    private static void drawEffectIcon(net.minecraft.client.gui.GuiGraphicsExtractor graphics, int x, int y) {
        // 18x18 icon: downward arrow above three water lines, turquoise like the mod icon,
        // but arranged like a compact status-effect glyph.
        int cyan = 0xFF55E7FF;
        int deep = 0xFF2AA9D6;

        // Arrow stem and head.
        graphics.fill(x + 8, y + 1, x + 10, y + 8, cyan);
        graphics.fill(x + 5, y + 6, x + 13, y + 8, cyan);
        graphics.fill(x + 6, y + 8, x + 12, y + 10, cyan);
        graphics.fill(x + 7, y + 10, x + 11, y + 12, cyan);

        // Waves.
        graphics.fill(x + 2, y + 14, x + 6, y + 15, deep);
        graphics.fill(x + 6, y + 15, x + 10, y + 16, cyan);
        graphics.fill(x + 10, y + 14, x + 14, y + 15, deep);
        graphics.fill(x + 14, y + 15, x + 16, y + 16, cyan);

        graphics.fill(x + 2, y + 16, x + 6, y + 17, cyan);
        graphics.fill(x + 6, y + 17, x + 10, y + 18, deep);
        graphics.fill(x + 10, y + 16, x + 14, y + 17, cyan);
        graphics.fill(x + 14, y + 17, x + 16, y + 18, deep);
    }
}
