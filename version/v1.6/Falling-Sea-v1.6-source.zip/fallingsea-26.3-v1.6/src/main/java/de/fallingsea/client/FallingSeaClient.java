package de.fallingsea.client;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import de.fallingsea.network.ConfigSnapshotPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;

/** A brief, vanilla-effect-inspired warning, not a persistent debug overlay. */
public final class FallingSeaClient implements ClientModInitializer {
    private static final int WIDTH = 138;
    private static final int HEIGHT = 34;
    private static final long MAX_SNAPSHOT_AGE_MS = 4_000L;

    private static boolean countdownEnabled;
    private static int warningSeconds;
    private static long remainingSeconds;
    private static long snapshotTimeMs;

    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(ConfigSnapshotPayload.TYPE, (packet, context) ->
            context.client().execute(() -> {
                JsonObject json;
                try {
                    json = JsonParser.parseString(packet.json()).getAsJsonObject();
                    boolean show = json.get("showCountdown").getAsBoolean();
                    boolean enabled = json.get("enableDrying").getAsBoolean();
                    boolean running = json.get("running").getAsBoolean();
                    int level = json.get("currentWaterLevel").getAsInt();
                    int minimum = json.get("minWaterLevel").getAsInt();
                    int window = json.get("countdownLastSeconds").getAsInt();
                    long seconds = json.get("countdownRemainingSeconds").getAsLong();
                    warningSeconds = Math.max(0, Math.min(60, window));
                    remainingSeconds = Math.max(0, seconds);
                    countdownEnabled = show && enabled && running && level > minimum && warningSeconds > 0;
                    snapshotTimeMs = System.currentTimeMillis();
                } catch (RuntimeException exception) {
                    countdownEnabled = false;
                    snapshotTimeMs = 0;
                    return;
                }
                if (context.client().gui.screen() instanceof FallingSeaConfigScreen screen) {
                    screen.receiveSnapshot(json);
                }
            })
        );

        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("fallingsea", "countdown"), (graphics, delta) -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.gui.hud.isHidden() || !countdownEnabled) return;
            long age = System.currentTimeMillis() - snapshotTimeMs;
            if (snapshotTimeMs == 0 || age < 0 || age > MAX_SNAPSHOT_AGE_MS) return;

            // Count down only during the configured warning window before the next step.
            long left = Math.max(0, remainingSeconds - age / 1_000L);
            if (left == 0 || left > warningSeconds) return;

            int x = Math.max(2, graphics.guiWidth() - WIDTH - 7);
            int y = 7;
            int right = x + WIDTH;
            int bottom = y + HEIGHT;

            // Compact status-effect-style panel: dark backing, subtle edge and icon.
            graphics.fill(x, y, right, bottom, 0xD9161616);
            graphics.fill(x, y, right, y + 1, 0xFF666666);
            graphics.fill(x, bottom - 1, right, bottom, 0xFF545454);
            graphics.fill(x, y, x + 1, bottom, 0xFF666666);
            graphics.fill(right - 1, y, right, bottom, 0xFF545454);

            // Two small cyan wave lines and a downward arrow: recognizable even without a texture.
            graphics.text(mc.font, "↓", x + 10, y + 4, 0xFF60DFFF, false);
            graphics.text(mc.font, "≈", x + 10, y + 17, 0xFF60DFFF, false);
            graphics.text(mc.font, "Austrocknung", x + 30, y + 5, 0xFFFFFFFF, false);
            long minutes = left / 60;
            long seconds = left % 60;
            String time = String.format(java.util.Locale.ROOT, "%d:%02d", minutes, seconds);
            graphics.text(mc.font, time, x + 30, y + 19, 0xFFAAAAAA, false);
        });
    }
}
