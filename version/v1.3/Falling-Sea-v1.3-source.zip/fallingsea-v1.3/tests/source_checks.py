"""Dependency-free structural and algorithm contract checks (not a Minecraft runtime test)."""
from pathlib import Path
import json, zipfile

ROOT=Path(__file__).resolve().parents[1]
java=list(ROOT.glob('src/main/java/**/*.java'))
assert len(java)==6, f'Unexpected Java file count: {len(java)}'
for f in java:
    source=f.read_text(encoding='utf8')
    # Lightweight delimiter scan, ignoring strings/comments to catch truncation.
    stack=[]
    i=0;mode='code'
    while i<len(source):
        c=source[i];n=source[i+1] if i+1<len(source) else ''
        if mode=='line':
            if c=='\n':mode='code'
        elif mode=='block':
            if c=='*' and n=='/':mode='code';i+=1
        elif mode in ('string','char'):
            if c=='\\':i+=1
            elif c==('"' if mode=='string' else "'"):mode='code'
        elif c=='/' and n=='/':mode='line';i+=1
        elif c=='/' and n=='*':mode='block';i+=1
        elif c=='"':mode='string'
        elif c=="'":mode='char'
        elif c in '({[':stack.append(c)
        elif c in ')}]':
            assert stack and stack.pop()=='({'[')}]'.index(c)],f'{f}: unbalanced {c}'
        i+=1
    assert not stack, f'{f}: unclosed delimiters {stack}'
    assert mode not in ('string','char','block'),f'{f}: unterminated literal/comment'

core=(ROOT/'src/main/java/de/fallingsea/FallingSea.java').read_text()
assert 'worker.invalidate();\n                    persist()' not in core
assert 'if(ready.getOrDefault(key,Integer.MAX_VALUE)==scannedLevel)continue;' in core
assert 'int bottom=bottomY(world,cfg,scannedLevel);' in core
assert 'completedPassLevel = scannedLevel;' in core
assert 'if(scannedLevel != target' in core or 'if (scannedLevel != target' in core
assert 'StandardCopyOption.ATOMIC_MOVE' in core
assert (ROOT/'src/main/resources/assets/fallingsea/icon.png').read_bytes()[:8]==bytes.fromhex('89504e470d0a1a0a')
json.load((ROOT/'config-example/fallingsea.json').open())
mod=json.load((ROOT/'src/main/resources/fabric.mod.json').open())
assert mod['id']=='fallingsea' and mod['icon']=='assets/fallingsea/icon.png'
assert 'mod_version=1.3' in (ROOT/'gradle.properties').read_text()
# Sea level removes *only* heights strictly above target through starting water height.
for start in [63,100,-10]:
    for target in [start,start-1,start-4]:
        for y in range(start-6,start+3):
            actual=y>target and y<=start
            expected=target<y<=start
            assert actual==expected
assert 'Commands.literal("refill")' in core
assert 'noch nicht gestartet' in core
assert 'config.enableDrying=true; save.running=true;' in core
assert 'cfg.suppressInfiniteSources &&' in core
print(f'Static checks passed: {len(java)} Java sources, delimiter balance, metadata, icon, scheduling invariants, sample sea-level boundaries.')
