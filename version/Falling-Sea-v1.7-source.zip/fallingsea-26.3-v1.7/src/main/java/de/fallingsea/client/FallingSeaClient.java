package de.fallingsea.client;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import de.fallingsea.network.ConfigSnapshotPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;

/** A brief, vanilla-effect-inspired warning, not a persistent debug overlay. */
public final class FallingSeaClient implements ClientModInitializer {
    private static final int WIDTH = 120;
    private static final int HEIGHT = 32;
    private static final long MAX_SNAPSHOT_AGE_MS = 4_000L;

    private static boolean countdownEnabled;
    private static int warningSeconds;
    private static long remainingSeconds;
    private static long snapshotTimeMs;

    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(ConfigSnapshotPayload.TYPE, (packet, context) ->
            context.client().execute(() -> {
                JsonObject json;
                try {
                    json = JsonParser.parseString(packet.json()).getAsJsonObject();
                    boolean show = json.get("showCountdown").getAsBoolean();
                    boolean enabled = json.get("enableDrying").getAsBoolean();
                    boolean running = json.get("running").getAsBoolean();
                    int level = json.get("currentWaterLevel").getAsInt();
                    int minimum = json.get("minWaterLevel").getAsInt();
                    int window = json.get("countdownLastSeconds").getAsInt();
                    long seconds = json.get("countdownRemainingSeconds").getAsLong();
                    warningSeconds = Math.max(0, Math.min(60, window));
                    remainingSeconds = Math.max(0, seconds);
                    countdownEnabled = show && enabled && running && level > minimum && warningSeconds > 0;
                    snapshotTimeMs = System.currentTimeMillis();
                } catch (RuntimeException exception) {
                    countdownEnabled = false;
                    snapshotTimeMs = 0;
                    return;
                }
                if (context.client().gui.screen() instanceof FallingSeaConfigScreen screen) {
                    screen.receiveSnapshot(json);
                }
            })
        );

        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("fallingsea", "countdown"), (graphics, delta) -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.gui.hud.isHidden() || !countdownEnabled) return;
            long age = System.currentTimeMillis() - snapshotTimeMs;
            if (snapshotTimeMs == 0 || age < 0 || age > MAX_SNAPSHOT_AGE_MS) return;

            // Count down only during the configured warning window before the next step.
            long left = Math.max(0, remainingSeconds - age / 1_000L);
            if (left == 0 || left > warningSeconds) return;

            int x = Math.max(2, graphics.guiWidth() - WIDTH - 5);
            int y = 5;
            // Vanilla inventory effect-list proportions: a compact 120x32 entry,
            // no custom border or permanently visible information panel.
            graphics.fill(x, y, x + WIDTH, y + HEIGHT, 0xCC1D1D1D);

            // Small pixel-art water-drop/descending-level effect glyph (16x18).
            int c = 0xFF55DFFF;
            graphics.fill(x + 12, y + 4, x + 15, y + 13, c);
            graphics.fill(x + 8, y + 11, x + 19, y + 13, c);
            graphics.fill(x + 10, y + 13, x + 17, y + 15, c);
            graphics.fill(x + 12, y + 15, x + 15, y + 17, c);
            graphics.fill(x + 7, y + 22, x + 12, y + 23, c);
            graphics.fill(x + 14, y + 22, x + 19, y + 23, c);
            graphics.fill(x + 9, y + 25, x + 17, y + 26, c);

            graphics.text(mc.font, "Austrocknung", x + 27, y + 5, 0xFFFFFFFF, false);
            long minutes = left / 60;
            long seconds = left % 60;
            String time = String.format(java.util.Locale.ROOT, "%d:%02d", minutes, seconds);
            graphics.text(mc.font, time, x + 27, y + 18, 0xFFAAAAAA, false);
        });
    }
}
