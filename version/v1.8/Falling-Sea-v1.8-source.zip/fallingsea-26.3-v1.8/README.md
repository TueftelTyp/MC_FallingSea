# Falling Sea v1.8 - Quellprojekt (Minecraft 26.3, Fabric)

**Wichtig: Diese Version wurde nicht gegen Minecraft 26.3 kompiliert und nicht im Spiel getestet.** Hier ist nur Java 21 verfügbar (Minecraft 26.3 benötigt Java 25). Es wäre falsch, diese Version als fehlerfrei oder als fertige, installierbare JAR zu kennzeichnen.

## Konkrete Fehlerkorrekturen gegenüber v1.2

- **Keine Scans trotz aktivem Status:** `running=true` bedeutete bisher nicht, dass auch `enableDrying=true` war. Die Befehle `start`, `lower` und `setlevel` aktivieren jetzt beide Voraussetzungen und starten die Verarbeitung neu. `/fallingsea status` zeigt diese getrennt an.
- **Ungueltige Scan-Anzeige:** Vor dem ersten Scan wird jetzt `noch nicht gestartet` statt `-2147483648` ausgegeben.
- **Nachfliessen umschaltbar:** In Mod Menu gibt es `Nachfliessen verhindern`, zusaetzlich `/fallingsea set refill true|false` (`true` = Vanilla-Nachfliessen erlauben). ACHTUNG: Das Verhindern besteht noch aus wiederholtem Entfernen nachfliessender Wasserbloecke, es ist keine Engine-weite Fluid-Sperre.
- **Icon:** Eigenstaendiges, pixeliges, dunkelblau-tuerkises Symbol mit fallendem Pfeil im Stil des Rising-Sea-Icons.

- **Scan-Starvation:** Wenn die Wasserzielhöhe während eines Scan-Durchlaufs sank (etwa bei kurzem Intervall), wurde die gesamte Warteschlange verworfen und vorne neu angefangen. Nun laufen Durchgänge zu Ende und scannen anschließend die neueste Höhe.
- **Endlose Wiederholungen:** Bereits fertig bearbeitete Chunks werden im gleichen Scan-Durchlauf nicht wieder eingereiht.
- **Spielernahe Verarbeitung:** Zu bearbeitende Chunks werden nach Entfernung zu Spielern sortiert.
- **Sichtbarer Scan-Status:** `/fallingsea status` zeigt Zielhöhe, gerade verarbeitete Höhe, letzte abgeschlossene Durchlaufhöhe und geänderte Blöcke. Der Zielwasserstand alleine ist kein Beweis für eine bearbeitete Fläche.
- **Standardwerte:** 5.000 Blockprüfungen/Tick, Radius 3 Chunks, Wiedervorlage alle 5 Sekunden. Bereits bestehende Konfigurationsdateien behalten ihre alten Werte, bis sie manuell geändert werden.
- **Sicherung:** Konfigurations-, Weltstatus- und Dürre-Baseline-Dateien werden über temporäre Dateien geschrieben und danach ersetzt; das reduziert kaputte Speicherstände bei Schreibabbrüchen.
- **Icon:** Eigene Darstellung einer trockenfallenden Küste.

## Modi

`SEA_LEVEL`: natürliche Wasserblöcke über der abgesenkten Zielhöhe bis zur konfigurierten Ausgangshöhe entfernen. `DROUGHT`: Wasser anhand einer persistenten, pro X/Z-Spalte ermittelten ursprünglichen Wasseroberfläche schrittweise entfernen.

## Einschränkungen

- Vanilla-Flüssigkeitsticks können Wasser erneut einströmen lassen. Die Option `suppressInfiniteSources` bewirkt **nur häufigeres Nachscannen**, keine garantierte Verhinderung der Wasserquellenerzeugung auf Engine-Ebene. Insbesondere an Chunkgrenzen kann die sichtbare Oberfläche zeitweise uneinheitlich sein.
- `DROUGHT` nutzt pro X/Z-Spalte nur **eine** Baseline und trocknet vertikal übereinander liegende Gewässer daher nicht vollständig unabhängig aus.
- Nur geladene Overworld-Chunks um Spieler werden angepasst. Der Modus `GLOBAL` erzeugt **keinen** echten Weltweit-Scan über ungeladene Chunks. Es gibt keine Chunk-Forceloads.
- Der Vorgang ist ohne Backup **irreversibel**: Wasser wird nicht wiederhergestellt, wenn die Zielhöhe steigt.
- Boote samt Insassen werden nicht künstlich versetzt. Sie reagieren auf die Vanilla-Wasserphysik.
- Die Mod sollte nicht zusammen mit Rising Sea in derselben Welt/Dimension eingesetzt werden.

## Build

Erfordert **JDK 25**, eine funktionsfähige Gradle-Installation und Internet-Zugang zu Loom/Minecraft/Fabric-Abhängigkeiten:

```
gradle clean build
```

Bei erfolgreichem Build wird die Datei unter `build/libs/` ausgegeben.

## Erster Test

1. Vollständiges **Backup der Welt** anlegen und alte Falling-Sea-Version entfernen.
2. In einer Testwelt mit OP-Rechten `/fallingsea set budget 5000` und `/fallingsea set rescan 5` setzen.
3. Mit `/fallingsea mode sea_level` waehlen (fuer das normale Meer), `/fallingsea start` ausfuehren und mit `/fallingsea setlevel 61` eine sichtbare Absenkung anfordern.
4. `/fallingsea status` mehrfach aufrufen und auf `letzte abgeschlossene Runde Y=61` achten. Nur so lässt sich erkennen, ob die sichtbare Wasserfläche überhaupt verarbeitet wurde.
5. Bei Wasser-Neubildung an Chunkgrenzen die Wasserposition und Serverlogs notieren. Eine vollständige Engine-Level-Unterdrückung ist noch nicht implementiert.

## Verfügbare Befehle

`/fallingsea set refill true`, `/fallingsea set refill false`, `/fallingsea status`, `/fallingsea config`, `/fallingsea start`, `/fallingsea stop`, `/fallingsea mode sea_level`, `/fallingsea mode drought`, `/fallingsea processing ahead`, `/fallingsea processing loaded`, `/fallingsea processing global`, `/fallingsea setlevel 61`, `/fallingsea lower 5`, `/fallingsea reload` sowie `/fallingsea set` für `interval`, `fallblocks`, `startlevel`, `minlevel`, `budget`, `radius`, `preload`, `rescan`, `countdownseconds`, `enabled`, `caves`, `waterlogged`, `ice`, `countdown`, `announce`, `pauseempty`, `newchunks`, `guard`, `sources`.

## Achtung bei Updates

Eine alte `config/fallingsea.json` wird beibehalten. War `enableDrying` in dieser Datei ausgeschaltet, aktiviert `/fallingsea start` die Verarbeitung nun ausdruecklich. Bei `DROUGHT` braucht ein einziger Chunk viele Abfragen, weil unterschiedliche Oberflaechenhoehen gefunden werden muessen. `SEA_LEVEL` ist fuer das Absenken des Ozeans schneller und der empfohlene Modus.

## Pruefstatus

Die quelltextbasierten Struktur- und Grenzfalltests unter `tests/source_checks.py` wurden ausgefuehrt. Kein vollstaendiger Java-Build, keine API-Verifikation, kein Testserver. Keine Garantie, dass Wasser bei allen Weltgeometrien dauerhaft verschwindet; fuer einen solchen Anspruch ist eine echte Fluid-Engine-Integration mit Minecraft-Tests notwendig.


## v1.6 Wasserpflanzen

Wasserzellen mit Kelp, Kelp-Pflanzen, Seegras, hohem Seegras und Blasensaeulen werden nun im Absenkungsbereich mitsamt dem Pflanzenblock entfernt. Andere wasserloggte Bau-Bloecke folgen weiterhin der Option `dryWaterlogged`. Ein erneuter Scan korrigiert moegliches Nachfliessen, falls `suppressInfiniteSources=true` eingestellt ist. Kein Build-/Spieltest in dieser Umgebung (Java 25 erforderlich).


## v1.6 changes

- Round-robin chunk scanning: each loaded chunk receives short processing slices, reducing temporary 16x16 water curtains caused by whole-chunk scanning.
- Automatic repeat scan (with `suppressInfiniteSources=true`) detects water flowing back from neighbouring chunks. With refill enabled, normal water physics is allowed.
- Countdown moved from the screen-centre action bar to a small top-right HUD. Server broadcasts timing snapshots every second.
- Distinct Falling Sea icon, styled like Rising Sea with water descending toward an exposed coast.

**Limits:** Water may still flow temporarily while work is pending. This is a server-side block scanner, not a low-level fluid physics mixin. `DROUGHT` mode still has the original per-column baseline limitations, especially for stacked water bodies. Minecraft 26.3 runtime compilation and in-game verification required before production.


## Countdown-UI in v1.6
Der Countdown erscheint als kleines, dunkles, an Vanilla-Statuseffekte angelehntes HUD-Feld oben rechts. Er wird **nur** fuer die letzten `countdownLastSeconds` Sekunden vor einer automatischen Absenkung eingeblendet (0 = deaktiviert). Er zeigt ausschliesslich den Effektname `Austrocknung` und die verbleibende Zeit `m:ss`, keine Y-Hoehe. Waehrend Pause, nach Erreichen der Mindesthoehe, bei deaktivierter Anzeige und ausserhalb der Vorwarnzeit ist er unsichtbar. Bei ausgeblendetem HUD (F1) wird auch dieser Hinweis ausgeblendet.


## v1.8: Anzeige und Debug-Ausgaben

- Countdown: 120 x 32 GUI-Einheiten, an Vanilla-Effektlisten angelehnte Anordnung ohne farbigen Rahmen. Nur in den letzten `countdownLastSeconds` Sekunden vor dem naechsten automatischen Schritt, ohne Zielhoehe.
- `debug` (Standard `false`): Automatische Chatmeldungen sind ausgeschaltet, ausser wenn `debug=true`. Auch manuell angeforderte `status`- und `config`-Chat-Ausgaben bleiben in diesem Modus still. Einstellungen werden weiter durch die GUI synchronisiert.
- `/fallingsea set debug true|false` oder die Option `Debug-Ausgaben im Chat` in Mod Menu. Das alte `announceFall` greift nur noch, wenn zugleich `debug=true`; es bleibt zum Einlesen bestehender Konfigurationsdateien erhalten.
- Keine Aenderung an der Wasser-/Chunk-Scan-Logik gegenueber v1.6.
