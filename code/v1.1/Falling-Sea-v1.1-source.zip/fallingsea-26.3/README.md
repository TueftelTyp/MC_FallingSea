# Falling Sea v1.1 (SOURCE / UNVERIFIED BUILD)

Independent Fabric mod for **Minecraft Java 26.3**, based on the project layout and client config synchronization of Rising Sea v6.1. Requires **Java 25** and Fabric API. Mod Menu is an optional config UI dependency.

## v1.1 fix for delayed or apparently stationary sea levels

The original scanner checked the entire height of every chunk even if only one sea layer needed removal. The SEA_LEVEL scanner now scans only blocks between the saved target and the configured starting level, so a one-block reduction takes about 256 checks per chunk rather than roughly 100,000. Ongoing scans are no longer restarted by the periodic rediscovery pass, and `/fallingsea status` reports completed and pending chunks and the number of changed blocks. A target announcement is NOT proof that the nearby sea has already been edited; observe the scan status. Periodic revisits are still needed because vanilla fluids can flow into cleared layers. The option named `suppressInfiniteSources` is still best-effort rescanning, not full engine-level source suppression.

## Modes

- `SEA_LEVEL`: Removes naturally occurring water layers strictly above the falling global sea-level target and at/below the starting sea level. Water high above the initial sea level is intentionally unaffected in this mode.
- `DROUGHT`: Removes the top N layers of water in each X/Z column, using a persistent record of the first water surface observed in that column. This includes elevated lakes and rivers. **Caveat:** isolated waters stacked at different heights in the same X/Z column share one baseline. Newly visited chunks after significant drying use the surface discovered on first visit, not a world-generation historical surface. This means delayed processing may under-dry some locations.

Both modes edit loaded Overworld chunks near players incrementally. Vanilla water fluid updates can temporarily regenerate source water: the `sources` setting increases the rescan frequency to clean it up, but **does not prevent source creation at the engine level**. This is not a perfect global water-source suppression solution.

## Critical limitations

**Back up the world before installation.** All removed natural water is irreversible from this mod's perspective. Raising the target again does NOT restore removed water. Chunks outside the loaded area are processed only when a player approaches them. Processing a chunk for the first time can take time (bounded by `blocksPerTick` block examinations per server tick). The optional `guard` is best effort and may feel restrictive. Boats and passengers are left to vanilla buoyancy and gravity, so they are never intentionally teleported or ejected by this mod. A boat may strand as water disappears.

The project was statically checked but **NOT compiled against 26.3 and NOT game-tested**. The local build environment does not provide JDK 25 or dependency download access. This ZIP is source, **not an installable mod JAR**. Building and in-game verification remain necessary.

## Build

Open this directory (containing `build.gradle`) with Gradle and **JDK 25**, with internet access for Loom, Minecraft, and Fabric dependencies, and run:

```text
gradle clean build
```

On successful build the expected artifact is `build/libs/fallingsea-1.1.jar`.

## Commands (OP / server console for changes)

```text
fallingsea status
fallingsea config
fallingsea mode sea_level
fallingsea mode drought
fallingsea processing ahead
fallingsea set interval 300
fallingsea set fallblocks 1
fallingsea set minlevel -64
fallingsea set waterlogged false
fallingsea set sources true
fallingsea setlevel 58
fallingsea lower 5
fallingsea start
fallingsea stop
fallingsea reload
```

Prefix these with `/` in Minecraft chat. The Mod Menu client screen has paging, config synchronization, and controls matching the commands.

## Persistence and compatibility

`config/fallingsea.json`, world `fallingsea-state.json` and `fallingsea-drought-baseline.dat.gz` are independent from Rising Sea. **Do not run Rising Sea and Falling Sea concurrently in the same dimension:** their world-editing behavior conflicts. Only the Overworld is processed. Default mode is `SEA_LEVEL`. The drought baseline is never cleared by changing modes; removing the ledger changes drought behavior.
