# Falling Sea v1.2 - Quellprojekt (Minecraft 26.3, Fabric)

**Wichtig: Diese Version wurde nicht gegen Minecraft 26.3 kompiliert und nicht im Spiel getestet.** Hier ist nur Java 21 verfügbar (Minecraft 26.3 benötigt Java 25). Es wäre falsch, diese Version als fehlerfrei oder als fertige, installierbare JAR zu kennzeichnen.

## Konkrete Fehlerkorrekturen gegenüber v1.1

- **Scan-Starvation:** Wenn die Wasserzielhöhe während eines Scan-Durchlaufs sank (etwa bei kurzem Intervall), wurde die gesamte Warteschlange verworfen und vorne neu angefangen. Nun laufen Durchgänge zu Ende und scannen anschließend die neueste Höhe.
- **Endlose Wiederholungen:** Bereits fertig bearbeitete Chunks werden im gleichen Scan-Durchlauf nicht wieder eingereiht.
- **Spielernahe Verarbeitung:** Zu bearbeitende Chunks werden nach Entfernung zu Spielern sortiert.
- **Sichtbarer Scan-Status:** `/fallingsea status` zeigt Zielhöhe, gerade verarbeitete Höhe, letzte abgeschlossene Durchlaufhöhe und geänderte Blöcke. Der Zielwasserstand alleine ist kein Beweis für eine bearbeitete Fläche.
- **Standardwerte:** 5.000 Blockprüfungen/Tick, Radius 3 Chunks, Wiedervorlage alle 5 Sekunden. Bereits bestehende Konfigurationsdateien behalten ihre alten Werte, bis sie manuell geändert werden.
- **Sicherung:** Konfigurations-, Weltstatus- und Dürre-Baseline-Dateien werden über temporäre Dateien geschrieben und danach ersetzt; das reduziert kaputte Speicherstände bei Schreibabbrüchen.
- **Icon:** Eigene Darstellung einer trockenfallenden Küste.

## Modi

`SEA_LEVEL`: natürliche Wasserblöcke über der abgesenkten Zielhöhe bis zur konfigurierten Ausgangshöhe entfernen. `DROUGHT`: Wasser anhand einer persistenten, pro X/Z-Spalte ermittelten ursprünglichen Wasseroberfläche schrittweise entfernen.

## Einschränkungen

- Vanilla-Flüssigkeitsticks können Wasser erneut einströmen lassen. Die Option `suppressInfiniteSources` bewirkt **nur häufigeres Nachscannen**, keine garantierte Verhinderung der Wasserquellenerzeugung auf Engine-Ebene. Insbesondere an Chunkgrenzen kann die sichtbare Oberfläche zeitweise uneinheitlich sein.
- `DROUGHT` nutzt pro X/Z-Spalte nur **eine** Baseline und trocknet vertikal übereinander liegende Gewässer daher nicht vollständig unabhängig aus.
- Nur geladene Overworld-Chunks um Spieler werden angepasst. Der Modus `GLOBAL` erzeugt **keinen** echten Weltweit-Scan über ungeladene Chunks. Es gibt keine Chunk-Forceloads.
- Der Vorgang ist ohne Backup **irreversibel**: Wasser wird nicht wiederhergestellt, wenn die Zielhöhe steigt.
- Boote samt Insassen werden nicht künstlich versetzt. Sie reagieren auf die Vanilla-Wasserphysik.
- Die Mod sollte nicht zusammen mit Rising Sea in derselben Welt/Dimension eingesetzt werden.

## Build

Erfordert **JDK 25**, eine funktionsfähige Gradle-Installation und Internet-Zugang zu Loom/Minecraft/Fabric-Abhängigkeiten:

```
gradle clean build
```

Bei erfolgreichem Build wird die Datei unter `build/libs/` ausgegeben.

## Erster Test

1. Vollständiges **Backup der Welt** anlegen und alte Falling-Sea-Version entfernen.
2. In einer Testwelt mit OP-Rechten `/fallingsea set budget 5000` und `/fallingsea set rescan 5` setzen.
3. Mit `/fallingsea setlevel 61` eine sichtbare Absenkung anfordern.
4. `/fallingsea status` mehrfach aufrufen und auf `letzte abgeschlossene Runde Y=61` achten. Nur so lässt sich erkennen, ob die sichtbare Wasserfläche überhaupt verarbeitet wurde.
5. Bei Wasser-Neubildung an Chunkgrenzen die Wasserposition und Serverlogs notieren. Eine vollständige Engine-Level-Unterdrückung ist noch nicht implementiert.

## Verfügbare Befehle

`/fallingsea status`, `/fallingsea config`, `/fallingsea start`, `/fallingsea stop`, `/fallingsea mode sea_level`, `/fallingsea mode drought`, `/fallingsea processing ahead`, `/fallingsea processing loaded`, `/fallingsea processing global`, `/fallingsea setlevel 61`, `/fallingsea lower 5`, `/fallingsea reload` sowie `/fallingsea set` für `interval`, `fallblocks`, `startlevel`, `minlevel`, `budget`, `radius`, `preload`, `rescan`, `countdownseconds`, `enabled`, `caves`, `waterlogged`, `ice`, `countdown`, `announce`, `pauseempty`, `newchunks`, `guard`, `sources`.
