package de.fallingsea;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import de.fallingsea.network.ConfigRequestPayload;
import de.fallingsea.network.ConfigSnapshotPayload;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.storage.LevelResource;

import java.io.*;
import java.nio.file.*;
import java.util.*;

/** Server-authoritative water removal. Never edits chunks off the main server thread. */
public final class FallingSea implements ModInitializer {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final String PREFIX = "[Falling Sea] ";
    private static final int TICKS_DAY = 24000;
    public static final class Settings {
        public String dryingMode = "SEA_LEVEL"; // SEA_LEVEL or DROUGHT
        public int intervalSeconds = 300;
        public int fallBlocks = 1;
        public int startingWaterLevel = 63;
        public int minWaterLevel = -64;
        public int blocksPerTick = 5000;
        public int chunkRadius = 3;
        public int preloadRadiusChunks = 3;
        public int rescanSeconds = 5;
        public String chunkProcessingMode = "AHEAD";
        public boolean enableDrying = true;
        public boolean dryCaves = true;
        public boolean dryWaterlogged = false;
        public boolean meltIce = false;
        public boolean showCountdown = true;
        public int countdownLastSeconds = 10;
        public boolean announceFall = true;
        public boolean pauseWhenEmpty = true;
        public boolean processNewChunks = true;
        public boolean blockUnpreparedChunkEntry = false;
        public boolean suppressInfiniteSources = true;
    }
    private static final class Save {
        int level = 63;
        long elapsedTicks;
        boolean running = true;
    }
    private Settings config = new Settings();
    private Save save = new Save();
    private MinecraftServer activeServer;
    private Path statePath;
    private int autosave;
    private final DryWorker worker = new DryWorker();
    private final Map<UUID, BlockPos> safePositions = new HashMap<>();

    @Override public void onInitialize() {
        readConfig();
        PayloadTypeRegistry.serverboundPlay().register(ConfigRequestPayload.TYPE, ConfigRequestPayload.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(ConfigSnapshotPayload.TYPE, ConfigSnapshotPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(ConfigRequestPayload.TYPE, (payload, ctx) -> snapshot(ctx.player()));
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            activeServer = server;
            statePath = server.getWorldPath(LevelResource.ROOT).resolve("fallingsea-state.json");
            readSave();
            worker.reset();
            worker.load(server.getWorldPath(LevelResource.ROOT).resolve("fallingsea-drought-baseline.dat.gz"));
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            persist(); worker.reset(); worker.clearBaselines(); safePositions.clear(); statePath = null; activeServer = null;
        });
        ServerTickEvents.END_SERVER_TICK.register(this::tick);
        registerCommands();
    }
    private void tick(MinecraftServer server) {
        if (statePath == null) return;
        if (config.pauseWhenEmpty && server.getPlayerList().getPlayers().isEmpty()) return;
        if (config.enableDrying && save.running) {
            if (save.level > config.minWaterLevel) {
                long interval = (long) config.intervalSeconds * 20;
                long remaining = interval - save.elapsedTicks;
                if (config.showCountdown && remaining > 0 && remaining <= (long)config.countdownLastSeconds * 20 && remaining % 20 == 0) {
                    for (ServerPlayer player : server.getPlayerList().getPlayers())
                        player.sendOverlayMessage(Component.literal("Naechste Austrocknung in " + (remaining / 20) + "s"));
                }
                if (++save.elapsedTicks >= interval) {
                    save.elapsedTicks = 0;
                    save.level = Math.max(config.minWaterLevel, save.level - config.fallBlocks);
                    // A running pass must finish before scanning the newer target.
                    persist(); snapshotAll();
                    if (config.announceFall) announce(server, "Wasserziel Y=" + save.level);
                }
            }
            worker.tick(server, config, save.level);
            if (config.blockUnpreparedChunkEntry) guard(server);
        }
        // Boats are intentionally NOT teleported downward into terrain or dry blocks.
        // Vanilla buoyancy and gravity naturally keep passengers on board as water recedes.
        if (++autosave >= 1200) { autosave = 0; persist(); }
    }
    private void guard(MinecraftServer server) {
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (!player.level().dimension().equals(Level.OVERWORLD)) continue;
            BlockPos pos = player.blockPosition();
            int cx = pos.getX() >> 4, cz = pos.getZ() >> 4;
            if (worker.ready(cx,cz, save.level)) safePositions.put(player.getUUID(), pos);
            else {
                BlockPos previous = safePositions.get(player.getUUID());
                if (previous != null && ((previous.getX() >> 4) != cx || (previous.getZ() >> 4) != cz)) {
                    player.setPos(previous.getX() + .5, previous.getY(), previous.getZ() + .5);
                    player.setDeltaMovement(0,0,0);
                }
            }
        }
    }
    private void registerCommands() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registry, environment) -> dispatcher.register(
            Commands.literal("fallingsea")
            .then(Commands.literal("status").executes(ctx -> {
                ctx.getSource().sendSuccess(() -> Component.literal(PREFIX + "Ziel Y="+save.level+" | Modus="+config.dryingMode+" | aktiv="+save.running+" | Scan: "+worker.progress()+" | naechster Schritt in "+Math.max(0,((long)config.intervalSeconds*20-save.elapsedTicks)/20)+"s"),false);
                return 1;
            }))
            .then(Commands.literal("config").executes(ctx -> {
                ctx.getSource().sendSuccess(() -> Component.literal(PREFIX+GSON.toJson(config)),false); return 1;
            }))
            .then(Commands.literal("start").requires(s -> s.permissions().hasPermission(net.minecraft.server.permissions.Permissions.COMMANDS_MODERATOR)).executes(ctx -> {
                save.running = true; persist(); snapshotAll(); announce(ctx.getSource().getServer(),"Austrocknung gestartet"); return 1;
            }))
            .then(Commands.literal("stop").requires(s -> s.permissions().hasPermission(net.minecraft.server.permissions.Permissions.COMMANDS_MODERATOR)).executes(ctx -> {
                save.running = false; persist(); snapshotAll(); announce(ctx.getSource().getServer(),"Austrocknung pausiert"); return 1;
            }))
            .then(Commands.literal("mode").requires(s -> s.permissions().hasPermission(net.minecraft.server.permissions.Permissions.COMMANDS_MODERATOR))
                .then(Commands.literal("sea_level").executes(ctx -> { mode("SEA_LEVEL"); return 1; }))
                .then(Commands.literal("drought").executes(ctx -> { mode("DROUGHT"); return 1; })))
            .then(Commands.literal("processing").requires(s -> s.permissions().hasPermission(net.minecraft.server.permissions.Permissions.COMMANDS_MODERATOR))
                .then(Commands.literal("ahead").executes(ctx -> { processing("AHEAD"); return 1; }))
                .then(Commands.literal("loaded").executes(ctx -> { processing("LOADED"); return 1; }))
                .then(Commands.literal("global").executes(ctx -> { processing("GLOBAL"); return 1; })))
            .then(Commands.literal("setlevel").requires(s -> s.permissions().hasPermission(net.minecraft.server.permissions.Permissions.COMMANDS_MODERATOR))
                .then(Commands.argument("y",IntegerArgumentType.integer(-64,319)).executes(ctx -> {
                    save.level = Math.max(config.minWaterLevel,Math.min(config.startingWaterLevel,IntegerArgumentType.getInteger(ctx,"y")));
                    save.elapsedTicks=0; persist(); snapshotAll(); return 1;
                })))
            .then(Commands.literal("lower").requires(s -> s.permissions().hasPermission(net.minecraft.server.permissions.Permissions.COMMANDS_MODERATOR))
                .then(Commands.argument("blocks",IntegerArgumentType.integer(1,256)).executes(ctx -> {
                    save.level = Math.max(config.minWaterLevel,save.level-IntegerArgumentType.getInteger(ctx,"blocks"));
                    save.elapsedTicks=0; persist(); snapshotAll(); return 1;
                })))
            .then(Commands.literal("reload").requires(s -> s.permissions().hasPermission(net.minecraft.server.permissions.Permissions.COMMANDS_MODERATOR)).executes(ctx -> {
                readConfig(); worker.invalidate(); snapshotAll(); return 1;
            }))
            .then(Commands.literal("set").requires(s -> s.permissions().hasPermission(net.minecraft.server.permissions.Permissions.COMMANDS_MODERATOR))
                .then(Commands.literal("interval").then(Commands.argument("value",IntegerArgumentType.integer()).executes(ctx -> numeric("interval",IntegerArgumentType.getInteger(ctx,"value")))))
                .then(Commands.literal("fallblocks").then(Commands.argument("value",IntegerArgumentType.integer()).executes(ctx -> numeric("fallblocks",IntegerArgumentType.getInteger(ctx,"value")))))
                .then(Commands.literal("startlevel").then(Commands.argument("value",IntegerArgumentType.integer()).executes(ctx -> numeric("startlevel",IntegerArgumentType.getInteger(ctx,"value")))))
                .then(Commands.literal("minlevel").then(Commands.argument("value",IntegerArgumentType.integer()).executes(ctx -> numeric("minlevel",IntegerArgumentType.getInteger(ctx,"value")))))
                .then(Commands.literal("budget").then(Commands.argument("value",IntegerArgumentType.integer()).executes(ctx -> numeric("budget",IntegerArgumentType.getInteger(ctx,"value")))))
                .then(Commands.literal("radius").then(Commands.argument("value",IntegerArgumentType.integer()).executes(ctx -> numeric("radius",IntegerArgumentType.getInteger(ctx,"value")))))
                .then(Commands.literal("preload").then(Commands.argument("value",IntegerArgumentType.integer()).executes(ctx -> numeric("preload",IntegerArgumentType.getInteger(ctx,"value")))))
                .then(Commands.literal("rescan").then(Commands.argument("value",IntegerArgumentType.integer()).executes(ctx -> numeric("rescan",IntegerArgumentType.getInteger(ctx,"value")))))
                .then(Commands.literal("countdownseconds").then(Commands.argument("value",IntegerArgumentType.integer()).executes(ctx -> numeric("countdownseconds",IntegerArgumentType.getInteger(ctx,"value")))))
                .then(Commands.literal("enabled").then(Commands.argument("value",BoolArgumentType.bool()).executes(ctx -> toggle("enabled",BoolArgumentType.getBool(ctx,"value")))))
                .then(Commands.literal("caves").then(Commands.argument("value",BoolArgumentType.bool()).executes(ctx -> toggle("caves",BoolArgumentType.getBool(ctx,"value")))))
                .then(Commands.literal("waterlogged").then(Commands.argument("value",BoolArgumentType.bool()).executes(ctx -> toggle("waterlogged",BoolArgumentType.getBool(ctx,"value")))))
                .then(Commands.literal("ice").then(Commands.argument("value",BoolArgumentType.bool()).executes(ctx -> toggle("ice",BoolArgumentType.getBool(ctx,"value")))))
                .then(Commands.literal("countdown").then(Commands.argument("value",BoolArgumentType.bool()).executes(ctx -> toggle("countdown",BoolArgumentType.getBool(ctx,"value")))))
                .then(Commands.literal("announce").then(Commands.argument("value",BoolArgumentType.bool()).executes(ctx -> toggle("announce",BoolArgumentType.getBool(ctx,"value")))))
                .then(Commands.literal("pauseempty").then(Commands.argument("value",BoolArgumentType.bool()).executes(ctx -> toggle("pauseempty",BoolArgumentType.getBool(ctx,"value")))))
                .then(Commands.literal("newchunks").then(Commands.argument("value",BoolArgumentType.bool()).executes(ctx -> toggle("newchunks",BoolArgumentType.getBool(ctx,"value")))))
                .then(Commands.literal("guard").then(Commands.argument("value",BoolArgumentType.bool()).executes(ctx -> toggle("guard",BoolArgumentType.getBool(ctx,"value")))))
                .then(Commands.literal("sources").then(Commands.argument("value",BoolArgumentType.bool()).executes(ctx -> toggle("sources",BoolArgumentType.getBool(ctx,"value"))))))
        ));
    }
    private int numeric(String key,int value) {
        switch(key) {
            case "interval" -> config.intervalSeconds=value;
            case "fallblocks" -> config.fallBlocks=value;
            case "startlevel" -> config.startingWaterLevel=value;
            case "minlevel" -> config.minWaterLevel=value;
            case "budget" -> config.blocksPerTick=value;
            case "radius" -> config.chunkRadius=value;
            case "preload" -> config.preloadRadiusChunks=value;
            case "rescan" -> config.rescanSeconds=value;
            case "countdownseconds" -> config.countdownLastSeconds=value;
        }
        validate(); writeConfig(); worker.invalidate(); snapshotAll(); return 1;
    }
    private int toggle(String key,boolean value) {
        switch(key) {
            case "enabled" -> config.enableDrying=value;
            case "caves" -> config.dryCaves=value;
            case "waterlogged" -> config.dryWaterlogged=value;
            case "ice" -> config.meltIce=value;
            case "countdown" -> config.showCountdown=value;
            case "announce" -> config.announceFall=value;
            case "pauseempty" -> config.pauseWhenEmpty=value;
            case "newchunks" -> config.processNewChunks=value;
            case "guard" -> config.blockUnpreparedChunkEntry=value;
            case "sources" -> config.suppressInfiniteSources=value;
        }
        writeConfig(); worker.invalidate(); snapshotAll(); return 1;
    }
    private void mode(String s) { config.dryingMode=s; writeConfig();worker.invalidate();snapshotAll(); }
    private void processing(String s) { config.chunkProcessingMode=s;writeConfig();worker.invalidate();snapshotAll(); }
    private void announce(MinecraftServer server,String msg) { server.getPlayerList().broadcastSystemMessage(Component.literal(PREFIX+msg),false); }
    private void snapshot(ServerPlayer player) {
        if (activeServer == null || player == null) return;
        JsonObject json=GSON.toJsonTree(config).getAsJsonObject();
        json.addProperty("currentWaterLevel",save.level);json.addProperty("running",save.running);
        ServerPlayNetworking.send(player,new ConfigSnapshotPayload(json.toString()));
    }
    private void snapshotAll() { if(activeServer!=null)for(ServerPlayer p:activeServer.getPlayerList().getPlayers())snapshot(p); }
    private Path configPath() { return FabricLoader.getInstance().getConfigDir().resolve("fallingsea.json"); }
    private void validate() {
        if (config.dryingMode == null || !Set.of("SEA_LEVEL","DROUGHT").contains(config.dryingMode))config.dryingMode="SEA_LEVEL";
        if (config.chunkProcessingMode == null || !Set.of("AHEAD","LOADED","GLOBAL").contains(config.chunkProcessingMode))config.chunkProcessingMode="AHEAD";
        config.intervalSeconds=Math.max(1,Math.min(86400,config.intervalSeconds));
        config.fallBlocks=Math.max(1,Math.min(100,config.fallBlocks));
        config.startingWaterLevel=Math.max(-64,Math.min(319,config.startingWaterLevel));
        config.minWaterLevel=Math.max(-64,Math.min(config.startingWaterLevel,config.minWaterLevel));
        config.blocksPerTick=Math.max(256,Math.min(20000,config.blocksPerTick));
        config.chunkRadius=Math.max(0,Math.min(8,config.chunkRadius));
        config.preloadRadiusChunks=Math.max(0,Math.min(16,config.preloadRadiusChunks));
        config.rescanSeconds=Math.max(1,Math.min(600,config.rescanSeconds));
        config.countdownLastSeconds=Math.max(0,Math.min(60,config.countdownLastSeconds));
    }
    private void readConfig() {
        try {
            if(Files.exists(configPath()))try(Reader in=Files.newBufferedReader(configPath())) {Settings x=GSON.fromJson(in,Settings.class);if(x!=null)config=x;}
            validate();writeConfig();
        } catch(Exception e) {System.err.println(PREFIX+"Konfiguration: "+e);}
    }
    private void writeConfig() {
        try {
            Path target = configPath();
            Files.createDirectories(target.getParent());
            Path temporary=target.resolveSibling(target.getFileName()+".tmp");
            try(Writer w=Files.newBufferedWriter(temporary)){GSON.toJson(config,w);}
            try { Files.move(temporary,target,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING); }
            catch(AtomicMoveNotSupportedException ex) { Files.move(temporary,target,StandardCopyOption.REPLACE_EXISTING); }
        } catch(Exception e){System.err.println(PREFIX+"Konfiguration schreiben: "+e);}
    }
    private void readSave() {
        save=new Save();save.level=config.startingWaterLevel;
        try {if(Files.exists(statePath))try(Reader r=Files.newBufferedReader(statePath)){Save x=GSON.fromJson(r,Save.class);if(x!=null)save=x;}}
        catch(Exception e){System.err.println(PREFIX+"Spielstand lesen: "+e);}
        save.level=Math.max(config.minWaterLevel,Math.min(config.startingWaterLevel,save.level));
        save.elapsedTicks=Math.max(0,save.elapsedTicks);
    }
    private void persist() {
        if(statePath==null)return;
        try {
            Path temporary = statePath.resolveSibling(statePath.getFileName() + ".tmp");
            try(Writer w=Files.newBufferedWriter(temporary)){GSON.toJson(save,w);}
            try { Files.move(temporary,statePath,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING); }
            catch(AtomicMoveNotSupportedException ex) { Files.move(temporary,statePath,StandardCopyOption.REPLACE_EXISTING); }
        } catch(Exception e){System.err.println(PREFIX+"Spielstand speichern: "+e);}
        worker.save(statePath.resolveSibling("fallingsea-drought-baseline.dat.gz"));
    }

    /** One scan unit = one block examined. No implicit chunk loads. */
    private static final class DryWorker {
        private record Target(ServerLevel world,int x,int z) {}
        private record ColumnKey(int x,int z) {}
        private final ArrayDeque<Target> queue=new ArrayDeque<>();
        private final Set<Long> queued=new HashSet<>();
        private final Set<Long> visited=new HashSet<>();
        private final Map<Long,Integer> ready=new HashMap<>();
        // Initial water surface per XZ column, for DROUGHT's per-surface relative depth.
        // Persisting this is essential: rescans must NOT advance drying again.
        private final Map<ColumnKey,Integer> originalSurface=new HashMap<>();
        private Target current;
        private int column,y,scanCooldown;
        private int completedPassLevel = Integer.MAX_VALUE;
        private boolean firstScan;
        private int completedChunks;
        private long examinedBlocks;
        private long removedBlocks;
        private int scannedLevel;
        private String scannedMode;
        private static long chunkKey(int cx,int cz){return ((long)cx<<32)^(cz&0xffffffffL);}
        void reset(){queue.clear();queued.clear();visited.clear();ready.clear();current=null;column=0;y=0;scanCooldown=0;firstScan=false;completedChunks=0;examinedBlocks=0;removedBlocks=0;scannedLevel=Integer.MIN_VALUE;completedPassLevel=Integer.MAX_VALUE;scannedMode=null;}
        void invalidate(){queue.clear();queued.clear();ready.clear();current=null;scanCooldown=0;firstScan=false;completedChunks=0;examinedBlocks=0;removedBlocks=0;scannedLevel=Integer.MIN_VALUE;completedPassLevel=Integer.MAX_VALUE;scannedMode=null;}
        void clearBaselines(){originalSurface.clear();}
        String progress(){return "bearbeite Y="+scannedLevel+", letzte abgeschlossene Runde Y="+(completedPassLevel==Integer.MAX_VALUE?"keine":completedPassLevel)+", "+completedChunks+" Chunks, "+(queue.size()+(current==null?0:1))+" offen, "+removedBlocks+" entfernt";}
        boolean ready(int cx,int cz,int level){return this.ready.getOrDefault(chunkKey(cx,cz),Integer.MAX_VALUE)==level;}
        void tick(MinecraftServer server,Settings cfg,int target) {
            // Never throw away an unfinished pass when the water target advances.
            // A short interval (e.g. one second) formerly restarted the scan over
            // and over, leaving outer chunks permanently wet.
            if (scannedMode != null && !cfg.dryingMode.equals(scannedMode)) invalidate();
            if (current == null && queue.isEmpty()) {
                if (scannedLevel != target || !cfg.dryingMode.equals(scannedMode)) {
                    startPass(server,cfg,target);
                } else if (++scanCooldown >= (cfg.suppressInfiniteSources ? 20 : cfg.rescanSeconds*20)) {
                    completedPassLevel = scannedLevel;
                    scanCooldown = 0;
                    ready.clear();
                    completedChunks = 0;
                    discover(server,cfg);
                }
            } else if (++scanCooldown >= 20) {
                scanCooldown = 0;
                // Track players entering new loaded chunks, but retain existing work.
                discover(server,cfg);
            }
            int remaining=cfg.blocksPerTick;
            while(remaining-->0){
                if(current==null){
                    current=queue.pollFirst();
                    if(current==null){
                        completedPassLevel = scannedLevel;
                        // If the target moved during this scan, begin the next pass
                        // immediately on the next tick. Never erase unfinished work.
                        return;
                    }
                    queued.remove(chunkKey(current.x,current.z));
                    column=0;
                    y=topY(current.world,cfg);
                }
                ServerLevel world=current.world;
                int cx=current.x,cz=current.z;
                if(!world.hasChunk(cx,cz)){current=null;continue;}
                int bottom=bottomY(world,cfg,scannedLevel);
                if(y<bottom){
                    y=topY(world,cfg);
                    if(++column==256){
                        ready.put(chunkKey(cx,cz),scannedLevel);
                        completedChunks++;
                        current=null;
                    }
                    continue;
                }
                int x=(cx<<4)+(column&15),z=(cz<<4)+(column>>>4);
                BlockPos pos=new BlockPos(x,y--,z);
                examinedBlocks++;
                BlockState block=world.getBlockState(pos);
                boolean water=block.is(Blocks.WATER);
                boolean waterlogged=block.hasProperty(BlockStateProperties.WATERLOGGED) && block.getValue(BlockStateProperties.WATERLOGGED);
                boolean ice=block.is(Blocks.ICE) || block.is(Blocks.FROSTED_ICE);
                if(!water && !(cfg.dryWaterlogged && waterlogged) && !(cfg.meltIce && ice))continue;
                if(!cfg.dryCaves && !world.canSeeSky(pos))continue;
                boolean remove;
                if("SEA_LEVEL".equals(cfg.dryingMode)) {
                    remove=pos.getY()>scannedLevel && pos.getY()<=cfg.startingWaterLevel;
                } else {
                    ColumnKey key=new ColumnKey(x,z);
                    int surface=originalSurface.computeIfAbsent(key,k->pos.getY());
                    int dryDepth=cfg.startingWaterLevel-scannedLevel;
                    remove=pos.getY()>surface-dryDepth;
                }
                if(!remove)continue;
                // Flag 2 updates clients without a broad immediate neighbour-update
                // cascade. Recurring scans catch fluid ticks that refill cleared cells.
                boolean changed = water || ice
                    ? world.setBlock(pos,Blocks.AIR.defaultBlockState(),2)
                    : world.setBlock(pos,block.setValue(BlockStateProperties.WATERLOGGED,false),2);
                if(changed)removedBlocks++;
            }
        }
        private void startPass(MinecraftServer server,Settings cfg,int target) {
            scannedLevel = target;
            scannedMode = cfg.dryingMode;
            completedChunks = 0;
            scanCooldown = 0;
            ready.clear();
            discover(server,cfg);
            firstScan = true;
        }
        private int topY(ServerLevel world,Settings cfg) {
            return "SEA_LEVEL".equals(cfg.dryingMode)
                ? Math.min(world.getMaxY()-1,cfg.startingWaterLevel)
                : world.getMaxY()-1;
        }
        private int bottomY(ServerLevel world,Settings cfg,int target) {
            return "SEA_LEVEL".equals(cfg.dryingMode)
                ? Math.max(world.getMinY(),target+1)
                : world.getMinY();
        }
        private void discover(MinecraftServer server,Settings cfg) {
            List<Target> candidates=new ArrayList<>();
            Set<Long> round=new HashSet<>();
            for(ServerPlayer player:server.getPlayerList().getPlayers()){
                ServerLevel world=player.level();if(!world.dimension().equals(Level.OVERWORLD))continue;
                int cx=player.blockPosition().getX()>>4,cz=player.blockPosition().getZ()>>4;
                int radius="LOADED".equals(cfg.chunkProcessingMode)?cfg.chunkRadius:Math.max(cfg.chunkRadius,cfg.preloadRadiusChunks);
                for(int dx=-radius;dx<=radius;dx++)for(int dz=-radius;dz<=radius;dz++){
                    int x=cx+dx,z=cz+dz;long key=chunkKey(x,z);
                    if(!world.hasChunk(x,z) || !round.add(key))continue;
                    if(ready.getOrDefault(key,Integer.MAX_VALUE)==scannedLevel)continue;
                    if(current!=null && current.world==world && current.x==x && current.z==z)continue;
                    if(!cfg.processNewChunks && firstScan && !visited.contains(key))continue;
                    visited.add(key);
                    if(queued.add(key))candidates.add(new Target(world,x,z));
                }
            }
            // Always work on the water visible to nearby players first.
            // In global mode, this is still bounded to loaded chunks.
            candidates.sort(Comparator.comparingDouble(t -> distance(t, server)));
            queue.addAll(candidates);
        }
        private double distance(Target target,MinecraftServer server){
            double best=Double.MAX_VALUE;
            for(ServerPlayer player:server.getPlayerList().getPlayers()){
                if(player.level()!=target.world)continue;
                double dx=target.x*16+8-player.getX(),dz=target.z*16+8-player.getZ();
                double forward=dx*player.getLookAngle().x+dz*player.getLookAngle().z;
                best=Math.min(best,Math.hypot(dx,dz)-Math.max(0,forward)*.65);
            }
            return best;
        }
        void load(Path file){
            originalSurface.clear();if(!Files.exists(file))return;
            try(DataInputStream in=new DataInputStream(new java.util.zip.GZIPInputStream(Files.newInputStream(file)))){
                int count=in.readInt();if(count<0 || count>5_000_000)throw new IOException("Invalid baseline count");
                for(int i=0;i<count;i++)originalSurface.put(new ColumnKey(in.readInt(),in.readInt()),in.readInt());
            }catch(Exception e){System.err.println(PREFIX+"Drought-Baselines lesen: "+e);}
        }
        void save(Path file){
            if(file==null)return;
            try {
                Path temporary = file.resolveSibling(file.getFileName() + ".tmp");
                try(DataOutputStream out=new DataOutputStream(new java.util.zip.GZIPOutputStream(Files.newOutputStream(temporary)))){
                    out.writeInt(originalSurface.size());
                    for(var entry:originalSurface.entrySet()){
                        out.writeInt(entry.getKey().x());out.writeInt(entry.getKey().z());out.writeInt(entry.getValue());
                    }
                }
                try { Files.move(temporary,file,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING); }
                catch(AtomicMoveNotSupportedException ex) { Files.move(temporary,file,StandardCopyOption.REPLACE_EXISTING); }
            }catch(Exception e){System.err.println(PREFIX+"Drought-Baselines schreiben: "+e);}
        }
    }
}
